import { initializeApp } from "firebase/app";
import { createUserWithEmailAndPassword, 
    getAuth,
     signInWithEmailAndPassword,
    signOut } from "firebase/auth";
import { EmailAuthProvider } from "firebase/auth/web-extension";
import { addDoc, collection, getFirestore } from "firebase/firestore";
import { toast } from "react-toastify";


const firebaseConfig = {
  apiKey: "AIzaSyD6sVM1pDZhjxSEMQ5-ST47EtjiCj64mNE",
  authDomain: "netflix-clone-b7535.firebaseapp.com",
  projectId: "netflix-clone-b7535",
  storageBucket: "netflix-clone-b7535.firebasestorage.app",
  messagingSenderId: "963557313223",
  appId: "1:963557313223:web:184d577033c02177b38ce2"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const signup = async(name, email, password) => {
try {
    const res = await createUserWithEmailAndPassword(auth, email, password);
    const user = res.user;
    await addDoc(collection(db, "user"), {
        uid: user.uid,
        name,
        AuthProvider: "Local",
        email,
    });
} catch (error) {
    console.log(error);
    toast.error(error.code.split('/')[1].split('-').join(" "));
}
}

const login = async(email, password) => {
    try {
        await signInWithEmailAndPassword(auth, email, password);
    } catch (error) {
        console.log(error);
        toast.error(error.code.split('/')[1].split('-').join(" "));
    }
}


const logout = () => { 
   signOut(auth);
}

export{auth, db, login, signup, logout};
